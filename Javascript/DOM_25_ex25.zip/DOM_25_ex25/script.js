const changeBtn = document.querySelector(".change-bg");

const resetBtn = document.querySelector(".reset-bg");


changeBtn.addEventListener("dblclick", function () {
    
    document.body.style.backgroundColor = "dodgerblue";
    console.log("Change Button clicked");

});

resetBtn.addEventListener("dblclick", function () {
    
    document.body.style.backgroundColor = "white";
    console.log("Reset Button clicked");
    
});